package org.zerock.sample;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

import lombok.Data;


@Data
@Service
public class Chef {

}
